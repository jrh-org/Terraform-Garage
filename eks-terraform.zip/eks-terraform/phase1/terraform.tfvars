###############################################################################
# phase1/terraform.tfvars  -  fill in your sandbox credentials
# DO NOT commit this file to git
###############################################################################

aws_access_key = "AKIA2ASP5IDL7RR5HGMA"
aws_secret_key = "0vkBrqsGofgBXyEyYtm+T2YsvuG2VSBQEwWblM93"
aws_region = "us-east-1"

project_name = "myapp"
environment  = "sandbox"

cluster_name       = "myapp-eks"
cluster_version    = "1.31"
node_instance_type = "t3.micro"
node_desired_size  = 3
node_min_size      = 1
node_max_size      = 3

kubectl_instance_type = "t3.micro"

# CN/SAN of the self-signed cert in phase1/certs/server.crt
domain_name = "my-services.jrh-test.com"

# NOTE: acm_certificate_arn is no longer needed here.
# The ACM module imports the cert from phase1/certs/ and its ARN is
# wired directly to the ALB module via module.acm.certificate_arn.
