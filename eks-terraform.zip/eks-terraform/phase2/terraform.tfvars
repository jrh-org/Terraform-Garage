###############################################################################
# phase2/terraform.tfvars  -  same credentials as phase1
# DO NOT commit this file to git
###############################################################################

aws_access_key = "AKIA2ASP5IDL7RR5HGMA"
aws_secret_key = "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"
aws_region = "us-east-1"
